const CACHE_NAME = 'agenda-ftc-v9-revisao-final';
const APP_SHELL = [
  './Agenda_Semanal_Marca_FTC.html',
  './firebase-config.js?v=6',
  './sync-code-firebase.js?v=6',
  './manifest.webmanifest',
  './icon-192.png',
  './icon-512.png',
  './icon-180.png',
  './Icone_Agenda_Marca_FTC.ico'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  const isApplicationCode = event.request.mode === 'navigate'
    || /\.(?:html|js|css|webmanifest)$/.test(url.pathname);

  // O código do aplicativo busca a versão publicada primeiro. O cache é apenas
  // a cópia de segurança para continuar funcionando sem internet.
  if (isApplicationCode) {
    event.respondWith(
      fetch(event.request).then(response => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
        return response;
      }).catch(() => caches.match(event.request).then(cached =>
        cached || caches.match('./Agenda_Semanal_Marca_FTC.html')
      ))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
      return response;
    }).catch(() => caches.match('./Agenda_Semanal_Marca_FTC.html')))
  );
});
