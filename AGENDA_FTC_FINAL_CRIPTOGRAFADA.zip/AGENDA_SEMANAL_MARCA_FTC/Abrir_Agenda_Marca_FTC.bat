@echo off
setlocal

set "AGENDA_FILE=%~dp0Agenda_Semanal_Marca_FTC.html"
if not exist "%AGENDA_FILE%" (
  echo Nao foi possivel encontrar o arquivo Agenda_Semanal_Marca_FTC.html.
  echo Mantenha todos os arquivos da agenda na mesma pasta.
  pause
  exit /b 1
)

set "AGENDA_LAUNCHER=%~f0"
set "AGENDA_ICON=%~dp0Icone_Agenda_Marca_FTC.ico"
powershell -NoProfile -Command "$desktop=[Environment]::GetFolderPath('Desktop'); $link=Join-Path $desktop 'Agenda Semanal Marca FTC.lnk'; $shell=New-Object -ComObject WScript.Shell; $shortcut=$shell.CreateShortcut($link); $shortcut.TargetPath=$env:AGENDA_LAUNCHER; $shortcut.WorkingDirectory=Split-Path $env:AGENDA_LAUNCHER; if(Test-Path $env:AGENDA_ICON){$shortcut.IconLocation=$env:AGENDA_ICON}; $shortcut.Save()" >nul 2>&1

set "AGENDA_URL=file:///%AGENDA_FILE:\=/%"

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if exist "%EDGE%" (
  start "" "%EDGE%" --app="%AGENDA_URL%" --start-maximized
) else (
  start "" msedge --app="%AGENDA_URL%" --start-maximized
)

endlocal
