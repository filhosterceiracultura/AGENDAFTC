// Cole abaixo a configuração do aplicativo Web criada no Firebase.
// Esses dados identificam o projeto; não coloque senha nem chave privada neste arquivo.
window.AGENDA_FTC_FIREBASE_CONFIG = {
  apiKey: 'AIzaSyDFZjWB1m5vF1t2LX1ijOsKYQ2m5m7xUKk',
  authDomain: 'agendaftc.firebaseapp.com',
  projectId: 'agendaftc',
  storageBucket: 'agendaftc.firebasestorage.app',
  messagingSenderId: '834627230023',
  appId: '1:834627230023:web:17485fad42b13a25339462'
};
