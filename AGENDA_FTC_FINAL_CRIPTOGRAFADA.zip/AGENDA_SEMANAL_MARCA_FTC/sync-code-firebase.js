const bridge = window.agendaFtcBridge;
const syncDialog = document.querySelector('#syncDialog');
const syncButton = document.querySelector('#syncButton');

if (bridge && syncDialog && syncButton) {
  const FIREBASE_VERSION = '12.17.1';
  const config = window.AGENDA_FTC_FIREBASE_CONFIG || {};
  const CODE_KEY = 'agenda-ftc-sync-code-v1';
  const SYNC_META_KEY = 'agenda-ftc-code-sync-meta-v1';
  const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const ENCRYPTED_VERSION = 2;
  const textEncoder = new TextEncoder();
  const textDecoder = new TextDecoder();
  const TWO_YEARS = 2 * 365 * 24 * 60 * 60 * 1000;

  const elements = {
    statusCard: document.querySelector('#syncStatusCard'),
    statusTitle: document.querySelector('#syncStatusTitle'),
    statusText: document.querySelector('#syncStatusText'),
    firstUse: document.querySelector('#syncFirstUse'),
    connected: document.querySelector('#syncConnected'),
    codeValue: document.querySelector('#syncCodeValue'),
    codeInput: document.querySelector('#existingSyncCode'),
    createCode: document.querySelector('#createSyncCode'),
    connectCode: document.querySelector('#connectSyncCode'),
    copyCode: document.querySelector('#copySyncCode'),
    syncNow: document.querySelector('#syncNowButton'),
    disconnect: document.querySelector('#disconnectSync'),
    enableAlerts: document.querySelector('#enableAlerts'),
    close: document.querySelector('#closeSyncDialog')
  };

  let firebaseApi = null;
  let firestore = null;
  let unsubscribe = null;
  let syncPromise = null;
  let syncTimer = null;
  let currentCode = normalizeCode(localStorage.getItem(CODE_KEY) || '');

  function now() {
    return Date.now();
  }

  function asTime(value) {
    const result = Number(value || 0);
    return Number.isFinite(result) ? result : 0;
  }

  function isConfigured() {
    return Boolean(config.apiKey && config.projectId && config.appId);
  }

  function normalizeCode(value) {
    return String(value || '')
      .toUpperCase()
      .replace(/[^A-HJ-NP-Z2-9]/g, '')
      .slice(0, 16);
  }

  function formatCode(value) {
    const clean = normalizeCode(value);
    return clean.match(/.{1,4}/g)?.join('-') || '';
  }

  function generateCode() {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return [...bytes].map(byte => CODE_ALPHABET[byte % CODE_ALPHABET.length]).join('');
  }

  function bytesToBase64(bytes) {
    let binary = '';
    for (let offset = 0; offset < bytes.length; offset += 0x8000) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
    }
    return btoa(binary);
  }

  function base64ToBytes(value) {
    const binary = atob(value);
    return Uint8Array.from(binary, character => character.charCodeAt(0));
  }

  async function sha256(value) {
    return new Uint8Array(await crypto.subtle.digest('SHA-256', textEncoder.encode(value)));
  }

  async function documentIdForCode(code) {
    const digest = await sha256(`agenda-ftc-documento-v2:${normalizeCode(code)}`);
    return [...digest].map(byte => byte.toString(16).padStart(2, '0')).join('');
  }

  async function encryptionKeyForCode(code) {
    const digest = await sha256(`agenda-ftc-chave-v2:${normalizeCode(code)}`);
    return crypto.subtle.importKey('raw', digest, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
  }

  async function encryptSnapshot(snapshot, code = currentCode) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await encryptionKeyForCode(code);
    const plaintext = textEncoder.encode(JSON.stringify(normalizeSnapshot(snapshot)));
    const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plaintext);
    return {
      version: ENCRYPTED_VERSION,
      updatedAt: asTime(snapshot.updatedAt || now()),
      iv: bytesToBase64(iv),
      payload: bytesToBase64(new Uint8Array(encrypted))
    };
  }

  async function decryptSnapshot(documentData, code = currentCode) {
    if (!documentData || documentData.version !== ENCRYPTED_VERSION) {
      throw new Error('Os dados deste código não possuem o formato seguro esperado.');
    }
    try {
      const key = await encryptionKeyForCode(code);
      const decrypted = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: base64ToBytes(documentData.iv) },
        key,
        base64ToBytes(documentData.payload)
      );
      return normalizeSnapshot(JSON.parse(textDecoder.decode(decrypted)));
    } catch (error) {
      throw new Error('Não foi possível abrir os dados protegidos deste código. Confira o código informado.');
    }
  }

  function loadMeta() {
    try {
      const saved = JSON.parse(localStorage.getItem(SYNC_META_KEY));
      return saved && typeof saved === 'object' ? {
        deletedTasks: {},
        deletedWeeklyWords: {},
        ownerUpdatedAt: 0,
        localUpdatedAt: 0,
        lastSyncedAt: 0,
        ...saved
      } : {
        deletedTasks: {},
        deletedWeeklyWords: {},
        ownerUpdatedAt: 0,
        localUpdatedAt: 0,
        lastSyncedAt: 0
      };
    } catch (error) {
      return {
        deletedTasks: {},
        deletedWeeklyWords: {},
        ownerUpdatedAt: 0,
        localUpdatedAt: 0,
        lastSyncedAt: 0
      };
    }
  }

  function saveMeta(meta) {
    const cutoff = now() - TWO_YEARS;
    for (const [id, deletedAt] of Object.entries(meta.deletedTasks || {})) {
      if (asTime(deletedAt) < cutoff) delete meta.deletedTasks[id];
    }
    for (const [key, deletedAt] of Object.entries(meta.deletedWeeklyWords || {})) {
      if (asTime(deletedAt) < cutoff) delete meta.deletedWeeklyWords[key];
    }
    localStorage.setItem(SYNC_META_KEY, JSON.stringify(meta));
  }

  function hasLocalContent(snapshot) {
    return Boolean(snapshot.ownerName || snapshot.tasks.length || Object.keys(snapshot.weeklyWords).length);
  }

  function buildLocalSnapshot() {
    const current = bridge.getSnapshot();
    const meta = loadMeta();
    if (!meta.localUpdatedAt && hasLocalContent(current)) meta.localUpdatedAt = now();
    if (!meta.ownerUpdatedAt && current.ownerName) meta.ownerUpdatedAt = meta.localUpdatedAt || now();
    const fallback = meta.localUpdatedAt || now();

    const snapshot = {
      version: 1,
      updatedAt: meta.localUpdatedAt || fallback,
      ownerName: current.ownerName || '',
      ownerLocked: Boolean(current.ownerLocked || current.ownerName),
      ownerUpdatedAt: asTime(meta.ownerUpdatedAt),
      tasks: current.tasks.map(task => ({
        ...task,
        updatedAt: asTime(task.updatedAt || task.createdAt || fallback)
      })),
      deletedTasks: { ...(meta.deletedTasks || {}) },
      weeklyWords: Object.fromEntries(
        Object.entries(current.weeklyWords || {}).map(([key, value]) => [key, {
          ...value,
          updatedAt: asTime(value.updatedAt || fallback)
        }])
      ),
      deletedWeeklyWords: { ...(meta.deletedWeeklyWords || {}) }
    };
    saveMeta(meta);
    return snapshot;
  }

  function normalizeSnapshot(value) {
    const source = value && typeof value === 'object' ? value : {};
    return {
      version: 1,
      updatedAt: asTime(source.updatedAt),
      ownerName: typeof source.ownerName === 'string' ? source.ownerName : '',
      ownerLocked: Boolean(source.ownerLocked || source.ownerName),
      ownerUpdatedAt: asTime(source.ownerUpdatedAt),
      tasks: Array.isArray(source.tasks)
        ? source.tasks.filter(task => task && task.id).map(task => ({
          ...task,
          updatedAt: asTime(task.updatedAt || task.createdAt)
        }))
        : [],
      deletedTasks: source.deletedTasks && typeof source.deletedTasks === 'object'
        ? source.deletedTasks
        : {},
      weeklyWords: source.weeklyWords && typeof source.weeklyWords === 'object'
        ? source.weeklyWords
        : {},
      deletedWeeklyWords: source.deletedWeeklyWords && typeof source.deletedWeeklyWords === 'object'
        ? source.deletedWeeklyWords
        : {}
    };
  }

  function mergeDeletionMaps(left = {}, right = {}) {
    const merged = {};
    for (const key of new Set([...Object.keys(left), ...Object.keys(right)])) {
      merged[key] = Math.max(asTime(left[key]), asTime(right[key]));
    }
    return merged;
  }

  function mergeSnapshots(localValue, remoteValue) {
    const local = normalizeSnapshot(localValue);
    const remote = normalizeSnapshot(remoteValue);
    const deletedTasks = mergeDeletionMaps(local.deletedTasks, remote.deletedTasks);
    const deletedWeeklyWords = mergeDeletionMaps(local.deletedWeeklyWords, remote.deletedWeeklyWords);

    const tasksById = new Map();
    for (const task of [...remote.tasks, ...local.tasks]) {
      const existing = tasksById.get(task.id);
      if (!existing || asTime(task.updatedAt) >= asTime(existing.updatedAt)) tasksById.set(task.id, task);
    }
    const tasks = [...tasksById.values()].filter(task =>
      asTime(deletedTasks[task.id]) < asTime(task.updatedAt)
    );

    const weeklyWords = {};
    for (const [key, value] of [...Object.entries(remote.weeklyWords), ...Object.entries(local.weeklyWords)]) {
      const existing = weeklyWords[key];
      if (!existing || asTime(value.updatedAt) >= asTime(existing.updatedAt)) weeklyWords[key] = value;
    }
    for (const [key, deletedAt] of Object.entries(deletedWeeklyWords)) {
      if (weeklyWords[key] && asTime(deletedAt) >= asTime(weeklyWords[key].updatedAt)) delete weeklyWords[key];
    }

    const localOwnerWins = local.ownerUpdatedAt >= remote.ownerUpdatedAt;
    const ownerName = localOwnerWins ? local.ownerName : remote.ownerName;
    const ownerUpdatedAt = Math.max(local.ownerUpdatedAt, remote.ownerUpdatedAt);
    const latestItemTime = Math.max(
      0,
      ...tasks.map(task => asTime(task.updatedAt)),
      ...Object.values(weeklyWords).map(value => asTime(value.updatedAt)),
      ...Object.values(deletedTasks).map(asTime),
      ...Object.values(deletedWeeklyWords).map(asTime),
      ownerUpdatedAt
    );

    return {
      version: 1,
      updatedAt: Math.max(local.updatedAt, remote.updatedAt, latestItemTime),
      ownerName,
      ownerLocked: Boolean(ownerName || (localOwnerWins ? local.ownerLocked : remote.ownerLocked)),
      ownerUpdatedAt,
      tasks,
      deletedTasks,
      weeklyWords,
      deletedWeeklyWords
    };
  }

  function rememberMergedSnapshot(snapshot) {
    const meta = loadMeta();
    meta.deletedTasks = { ...(snapshot.deletedTasks || {}) };
    meta.deletedWeeklyWords = { ...(snapshot.deletedWeeklyWords || {}) };
    meta.ownerUpdatedAt = asTime(snapshot.ownerUpdatedAt);
    meta.localUpdatedAt = asTime(snapshot.updatedAt);
    meta.lastSyncedAt = now();
    saveMeta(meta);
    bridge.applySnapshot(snapshot);
  }

  function setStatus(state, title, text) {
    elements.statusCard.dataset.state = state;
    elements.statusTitle.textContent = title;
    elements.statusText.textContent = text;
  }

  function renderConnectionState() {
    const connected = currentCode.length === 16;
    elements.firstUse.classList.toggle('sync-hidden', connected);
    elements.connected.classList.toggle('sync-hidden', !connected);
    elements.codeValue.textContent = connected ? formatCode(currentCode) : '—';

    if (!isConfigured()) {
      bridge.setSyncUi({
        state: 'inactive',
        label: '☁ Ativar sincronização',
        detail: 'Configuração da agenda online pendente.'
      });
      setStatus('inactive', 'Configuração pendente', 'O mecanismo por código está pronto. Falta conectar o banco de dados online.');
    } else if (!connected) {
      bridge.setSyncUi({
        state: 'inactive',
        label: '☁ Ativar sincronização',
        detail: 'Crie seu código ou conecte um código existente.'
      });
      setStatus('inactive', 'Sincronização desativada', 'Crie um código neste aparelho ou conecte usando um código já existente.');
    }
  }

  async function ensureFirebase() {
    if (!isConfigured()) throw new Error('Falta configurar o banco online da Agenda FTC.');
    if (firebaseApi && firestore) return;

    const appModule = await import(`https://www.gstatic.com/firebasejs/${FIREBASE_VERSION}/firebase-app.js`);
    const firestoreModule = await import(`https://www.gstatic.com/firebasejs/${FIREBASE_VERSION}/firebase-firestore.js`);
    const app = appModule.initializeApp(config);
    firestore = firestoreModule.getFirestore(app);
    firebaseApi = firestoreModule;
  }

  async function agendaRef(code = currentCode) {
    return firebaseApi.doc(firestore, 'agendas', await documentIdForCode(code));
  }

  async function synchronize({ quiet = false } = {}) {
    if (syncPromise) return syncPromise;
    syncPromise = (async () => {
      await ensureFirebase();
      if (currentCode.length !== 16) throw new Error('Este aparelho ainda não possui um código de sincronização.');
      if (!quiet) {
        bridge.setSyncUi({ state: 'busy', label: '☁ Sincronizando…', detail: 'Comparando este aparelho com a agenda online.' });
        setStatus('active', 'Sincronizando…', 'Comparando este aparelho com a agenda online.');
      }

      const local = buildLocalSnapshot();
      const merged = await firebaseApi.runTransaction(firestore, async transaction => {
        const reference = await agendaRef();
        const documentSnapshot = await transaction.get(reference);
        if (!documentSnapshot.exists()) throw new Error('Este código não foi encontrado na agenda online.');
        const remote = await decryptSnapshot(documentSnapshot.data());
        const result = mergeSnapshots(local, remote);
        transaction.set(reference, await encryptSnapshot(result));
        return result;
      });

      rememberMergedSnapshot(merged);
      bridge.setSyncUi({ state: 'active', label: '☁ Sincronização ativa', detail: `Código ${formatCode(currentCode)} conectado.` });
      setStatus('active', 'Sincronização ativa', 'Os compromissos deste aparelho estão ligados à agenda online.');
      if (!quiet) bridge.showToast('Agenda sincronizada');
    })().catch(error => {
      console.error('Agenda FTC — sincronização por código:', error);
      bridge.setSyncUi({ state: 'error', label: '☁ Tentar sincronizar', detail: error.message || 'Não foi possível sincronizar agora.' });
      setStatus('error', 'Não foi possível sincronizar', error.message || 'Verifique a internet e tente novamente.');
      if (!quiet) alert(error.message || 'Não foi possível sincronizar agora.');
    }).finally(() => {
      syncPromise = null;
    });
    return syncPromise;
  }

  function scheduleSync() {
    if (currentCode.length !== 16 || !navigator.onLine) return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(() => synchronize({ quiet: true }), 1200);
  }

  async function attachRealtimeListener() {
    if (unsubscribe) unsubscribe();
    if (!firestore || currentCode.length !== 16) return;
    const reference = await agendaRef();
    unsubscribe = firebaseApi.onSnapshot(reference, async documentSnapshot => {
      if (!documentSnapshot.exists()) {
        setStatus('error', 'Código não encontrado', 'A agenda online ligada a este código não existe mais.');
        return;
      }
      if (documentSnapshot.metadata.hasPendingWrites) return;
      try {
        const local = buildLocalSnapshot();
        const remote = await decryptSnapshot(documentSnapshot.data());
        const merged = mergeSnapshots(local, remote);
        rememberMergedSnapshot(merged);
        bridge.setSyncUi({ state: 'active', label: '☁ Sincronização ativa', detail: `Código ${formatCode(currentCode)} conectado.` });
        setStatus('active', 'Sincronização ativa', 'Os compromissos estão atualizados neste aparelho.');
        if (JSON.stringify(merged) !== JSON.stringify(remote)) scheduleSync();
      } catch (error) {
        console.error('Agenda FTC — proteção dos dados:', error);
        setStatus('error', 'Dados protegidos', error.message || 'Não foi possível abrir os dados deste código.');
      }
    }, error => {
      console.error('Agenda FTC — atualização online:', error);
      setStatus('error', 'Conexão interrompida', 'Verifique a internet. Seus dados continuam salvos neste aparelho.');
    });
  }

  async function createNewCode() {
    if (!isConfigured()) {
      alert('O código da agenda está pronto, mas ainda falta configurar o banco de dados online.');
      return;
    }
    try {
      await ensureFirebase();
      setStatus('active', 'Criando seu código…', 'Preparando uma agenda online particular.');
      bridge.setSyncUi({ state: 'busy', label: '☁ Preparando…', detail: 'Criando seu código particular.' });

      let createdCode = '';
      for (let attempt = 0; attempt < 5 && !createdCode; attempt += 1) {
        const candidate = generateCode();
        try {
          const snapshot = buildLocalSnapshot();
          await firebaseApi.runTransaction(firestore, async transaction => {
            const reference = await agendaRef(candidate);
            const existing = await transaction.get(reference);
            if (existing.exists()) throw new Error('code-collision');
            transaction.set(reference, await encryptSnapshot(snapshot, candidate));
          });
          createdCode = candidate;
        } catch (error) {
          if (error.message !== 'code-collision') throw error;
        }
      }
      if (!createdCode) throw new Error('Não foi possível criar um código único. Tente novamente.');

      currentCode = createdCode;
      localStorage.setItem(CODE_KEY, currentCode);
      renderConnectionState();
      await attachRealtimeListener();
      bridge.setSyncUi({ state: 'active', label: '☁ Sincronização ativa', detail: `Código ${formatCode(currentCode)} conectado.` });
      setStatus('active', 'Sincronização ativa', 'Seu código foi criado e esta agenda já está online.');
      bridge.showToast('Código de sincronização criado');
    } catch (error) {
      console.error('Agenda FTC — criação do código:', error);
      setStatus('error', 'Não foi possível criar o código', error.message || 'Verifique a internet e tente novamente.');
      bridge.setSyncUi({ state: 'error', label: '☁ Tentar novamente', detail: error.message || 'Não foi possível criar o código.' });
      alert(error.message || 'Não foi possível criar o código.');
    }
  }

  async function connectExistingCode() {
    const requestedCode = normalizeCode(elements.codeInput.value);
    if (requestedCode.length !== 16) {
      alert('Digite o código completo com 16 letras e números.');
      elements.codeInput.focus();
      return;
    }
    if (!isConfigured()) {
      alert('A conexão por código está pronta, mas ainda falta configurar o banco de dados online.');
      return;
    }

    try {
      await ensureFirebase();
      setStatus('active', 'Procurando sua agenda…', 'Buscando o código informado na agenda online.');
      const reference = await agendaRef(requestedCode);
      const documentSnapshot = await firebaseApi.getDoc(reference);
      if (!documentSnapshot.exists()) throw new Error('Código não encontrado. Confira a escrita e tente novamente.');

      currentCode = requestedCode;
      localStorage.setItem(CODE_KEY, currentCode);
      const remote = await decryptSnapshot(documentSnapshot.data(), requestedCode);
      const merged = mergeSnapshots(buildLocalSnapshot(), remote);
      rememberMergedSnapshot(merged);
      await firebaseApi.setDoc(reference, await encryptSnapshot(merged));
      renderConnectionState();
      await attachRealtimeListener();
      bridge.setSyncUi({ state: 'active', label: '☁ Sincronização ativa', detail: `Código ${formatCode(currentCode)} conectado.` });
      setStatus('active', 'Sincronização ativa', 'Este aparelho foi conectado à sua agenda online.');
      bridge.showToast('Aparelho conectado');
    } catch (error) {
      console.error('Agenda FTC — conexão por código:', error);
      setStatus('error', 'Não foi possível conectar', error.message || 'Verifique o código e a internet.');
      alert(error.message || 'Não foi possível conectar com este código.');
    }
  }

  function disconnectDevice() {
    if (!confirm('Desconectar este aparelho da agenda online?\n\nOs compromissos continuarão salvos neste aparelho.')) return;
    if (unsubscribe) unsubscribe();
    unsubscribe = null;
    currentCode = '';
    localStorage.removeItem(CODE_KEY);
    localStorage.removeItem(SYNC_META_KEY);
    elements.codeInput.value = '';
    renderConnectionState();
    bridge.showToast('Aparelho desconectado');
  }

  async function copyCurrentCode() {
    const formatted = formatCode(currentCode);
    try {
      await navigator.clipboard.writeText(formatted);
      bridge.showToast('Código copiado');
    } catch (error) {
      prompt('Copie seu código:', formatted);
    }
  }

  async function enableAlerts() {
    if (!('Notification' in window)) {
      alert('Este navegador não oferece alarmes para aplicativos instalados.');
      return;
    }
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      elements.enableAlerts.textContent = '🔔 Alarmes autorizados';
      alert('Permissão concedida. Os alarmes funcionam enquanto a agenda estiver aberta; o funcionamento em segundo plano depende do aparelho.');
    } else {
      alert('A permissão para alarmes não foi concedida.');
    }
  }

  function handleLocalChange(event) {
    const detail = event.detail || {};
    if (detail.type === 'reset') {
      if (unsubscribe) unsubscribe();
      unsubscribe = null;
      currentCode = '';
      localStorage.removeItem(CODE_KEY);
      localStorage.removeItem(SYNC_META_KEY);
      renderConnectionState();
      return;
    }

    const meta = loadMeta();
    const changedAt = asTime(detail.updatedAt || detail.deletedAt || now());
    meta.localUpdatedAt = Math.max(asTime(meta.localUpdatedAt), changedAt);
    if (detail.type === 'owner') meta.ownerUpdatedAt = changedAt;
    if (detail.type === 'task-delete' && detail.id) meta.deletedTasks[detail.id] = changedAt;
    if (detail.type === 'weekly-word-delete' && detail.key) meta.deletedWeeklyWords[detail.key] = changedAt;
    saveMeta(meta);
    scheduleSync();
  }

  syncButton.addEventListener('click', () => {
    renderConnectionState();
    syncDialog.showModal();
  });
  elements.close.addEventListener('click', () => syncDialog.close());
  elements.createCode.addEventListener('click', createNewCode);
  elements.connectCode.addEventListener('click', connectExistingCode);
  elements.copyCode.addEventListener('click', copyCurrentCode);
  elements.syncNow.addEventListener('click', () => synchronize());
  elements.disconnect.addEventListener('click', disconnectDevice);
  elements.enableAlerts.addEventListener('click', enableAlerts);
  elements.codeInput.addEventListener('input', () => {
    const cursorAtEnd = elements.codeInput.selectionStart === elements.codeInput.value.length;
    elements.codeInput.value = formatCode(elements.codeInput.value);
    if (cursorAtEnd) elements.codeInput.setSelectionRange(elements.codeInput.value.length, elements.codeInput.value.length);
  });
  elements.codeInput.addEventListener('keydown', event => {
    if (event.key === 'Enter') connectExistingCode();
  });
  window.addEventListener('agenda-ftc:changed', handleLocalChange);
  window.addEventListener('online', () => scheduleSync());
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') scheduleSync();
  });

  renderConnectionState();
  if (isConfigured() && currentCode.length === 16) {
    ensureFirebase().then(async () => {
      await attachRealtimeListener();
      synchronize({ quiet: true });
    }).catch(error => {
      console.error('Agenda FTC — inicialização online:', error);
      bridge.setSyncUi({ state: 'error', label: '☁ Tentar sincronizar', detail: 'Não foi possível conectar à agenda online.' });
    });
  }
}
